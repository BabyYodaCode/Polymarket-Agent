# Keep main activity and JS bridge — bridge methods called by name from JavaScript
-keep class com.polymarket.agent.MainActivity { *; }
-keep class com.polymarket.agent.MainActivity$Bridge { *; }
-keepclassmembers class com.polymarket.agent.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}

# AndroidX
-keep class androidx.appcompat.** { *; }
-keep class androidx.webkit.**    { *; }
-dontwarn androidx.**

# JSON
-keep class org.json.** { *; }
