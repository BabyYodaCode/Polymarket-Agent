# Сборка Polymarket Agent APK

## Вариант 1 — Android Studio (рекомендуется, 15 минут)

### Шаг 1: Установите Android Studio
Скачайте с https://developer.android.com/studio и установите.
При первом запуске он сам скачает Android SDK.

### Шаг 2: Откройте проект
- File → Open → выберите папку `polymarket_android`
- Android Studio скачает зависимости (~2-3 мин)

### Шаг 3: Соберите APK
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
Готовый APK будет в:
```
app/build/outputs/apk/debug/app-debug.apk
```

### Шаг 4: Установите на телефон
- Включите «Установка из неизвестных источников» в настройках Android
- Перенесите APK на телефон и откройте

---

## Вариант 2 — Командная строка (если Java 17 уже установлена)

```bash
# macOS/Linux
cd polymarket_android
chmod +x gradlew
./gradlew assembleDebug

# Windows
cd polymarket_android
gradlew.bat assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

---

## Вариант 3 — GitHub Actions (онлайн, бесплатно)

1. Загрузите папку `polymarket_android` в GitHub репозиторий
2. Создайте файл `.github/workflows/build.yml`:

```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with: { java-version: '17', distribution: 'temurin' }
      - run: chmod +x gradlew && ./gradlew assembleDebug
      - uses: actions/upload-artifact@v3
        with:
          name: app-debug.apk
          path: app/build/outputs/apk/debug/app-debug.apk
```

3. Push в репозиторий → Actions → скачайте APK из Artifacts

---

## Требования для сборки
- Java 17+ (входит в Android Studio)
- Android SDK 34 (скачивается автоматически)
- Gradle 8.4 (скачивается автоматически через wrapper)
- Интернет для первой сборки (~500 MB зависимостей)

## Структура проекта
```
polymarket_android/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── assets/
│   │   │   └── app.html          ← весь UI (HTML/CSS/JS)
│   │   ├── java/com/polymarket/agent/
│   │   │   └── MainActivity.java ← WebView + Android Bridge
│   │   └── res/
│   │       ├── values/           ← strings, colors, themes
│   │       ├── mipmap-*/         ← иконки
│   │       └── xml/              ← network security config
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
├── gradle.properties
└── gradle/wrapper/
    └── gradle-wrapper.properties
```

## Минимальные требования к устройству
- Android 8.0 (API 26) или новее
- 50 MB свободного места
- Интернет-соединение для работы агента
