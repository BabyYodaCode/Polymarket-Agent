package com.polymarket.agent;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

/**
 * Polymarket Trading Agent — Android host Activity.
 *
 * Wraps the bundled HTML/JS app (assets/app.html) in a full-screen WebView
 * and exposes a JavaScript bridge ("Android") for native features.
 *
 * All deprecated API usages fixed for AGP 8.2 / targetSdk 34.
 */
@SuppressLint("SetJavaScriptEnabled")
public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private static final String PREFS   = "PolymarketPrefs";
    private static final String APP_URL = "file:///android_asset/app.html";

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        applyEdgeToEdge();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#080C14"));
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#080C14"));
        root.addView(webView, FrameLayout.LayoutParams.MATCH_PARENT,
                              FrameLayout.LayoutParams.MATCH_PARENT);

        configureWebView();
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.loadUrl(APP_URL);

        // FIX: Use OnBackPressedCallback instead of deprecated onBackPressed()
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack();
                } else {
                    webView.evaluateJavascript(
                        "typeof onAndroidBack==='function'&&onAndroidBack()",
                        result -> {
                            if (!"true".equals(result)) {
                                setEnabled(false);
                                getOnBackPressedDispatcher().onBackPressed();
                            }
                        });
                }
            }
        });
    }

    @Override protected void onResume() { super.onResume(); webView.onResume(); }
    @Override protected void onPause()  { webView.onPause(); super.onPause(); }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    // ── WebView configuration ─────────────────────────────────────────────────

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setDefaultTextEncodingName("UTF-8");
        s.setMinimumFontSize(8);
        s.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        // FIX: setDatabaseEnabled removed (deprecated no-op since API 19)
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        // FIX: FORCE_DARK removed — field was dropped in webkit 1.9.0 causing
        //      NoSuchFieldError at runtime. Dark theme handled in HTML/CSS.

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                android.util.Log.d("PM-WebView",
                    m.message() + " [" + m.sourceId() + ":" + m.lineNumber() + "]");
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                String url = req.getUrl().toString();
                if (url.startsWith("file://") || url.startsWith("about:")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, req.getUrl())); }
                catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                // Tell JS it's running inside an APK
                String js = "window.isAndroid=true;"
                          + "window.androidSdk=" + Build.VERSION.SDK_INT + ";"
                          + "if(typeof onAndroidReady==='function')onAndroidReady();";
                v.evaluateJavascript(js, null);
            }
        });
    }

    // ── JavaScript Bridge ─────────────────────────────────────────────────────

    private class Bridge {

        @JavascriptInterface
        public void showToast(String msg) {
            runOnUiThread(() ->
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }

        @JavascriptInterface
        public void saveSetting(String key, String value) {
            getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(key, value).apply();
        }

        @JavascriptInterface
        public String loadSetting(String key) {
            return getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(key, "");
        }

        @JavascriptInterface
        public String loadAllSettings() {
            try {
                JSONObject j = new JSONObject();
                SharedPreferences p = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
                for (String k : p.getAll().keySet()) j.put(k, p.getString(k, ""));
                return j.toString();
            } catch (Exception e) { return "{}"; }
        }

        // FIX: NetworkInfo removed (deprecated API 29+)
        //      Use NetworkCapabilities (available API 21+, well within minSdk 26)
        @JavascriptInterface
        public boolean isNetworkAvailable() {
            ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network net = cm.getActiveNetwork();
            if (net == null) return false;
            NetworkCapabilities caps = cm.getNetworkCapabilities(net);
            return caps != null
                && (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                 || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                 || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
        }

        @JavascriptInterface
        public String getDeviceInfo() {
            try {
                JSONObject j = new JSONObject();
                j.put("os",      "Android");
                j.put("version", Build.VERSION.RELEASE);
                j.put("sdk",     Build.VERSION.SDK_INT);
                j.put("model",   Build.MODEL);
                j.put("brand",   Build.BRAND);
                return j.toString();
            } catch (Exception e) { return "{}"; }
        }

        // FIX: Vibrator/VIBRATOR_SERVICE deprecated API 31 → use VibratorManager on 31+
        @JavascriptInterface
        public void vibrate() {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    VibratorManager vm = (VibratorManager)
                        getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
                    if (vm != null) {
                        vm.getDefaultVibrator().vibrate(
                            VibrationEffect.createOneShot(
                                30, VibrationEffect.DEFAULT_AMPLITUDE));
                    }
                } else {
                    @SuppressWarnings("deprecation")
                    Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                    if (v != null && v.hasVibrator()) {
                        v.vibrate(VibrationEffect.createOneShot(
                            30, VibrationEffect.DEFAULT_AMPLITUDE));
                    }
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void copyToClipboard(String text) {
            runOnUiThread(() -> {
                android.content.ClipboardManager cm =
                    (android.content.ClipboardManager)
                        getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) {
                    cm.setPrimaryClip(
                        android.content.ClipData.newPlainText("Copied", text));
                    Toast.makeText(MainActivity.this,
                        "Скопировано", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    // ── Edge-to-edge / status bar ─────────────────────────────────────────────

    private void applyEdgeToEdge() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        getWindow().setStatusBarColor(Color.parseColor("#080C14"));
        getWindow().setNavigationBarColor(Color.parseColor("#080C14"));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setDecorFitsSystemWindows(false);
            android.view.WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.setSystemBarsAppearance(
                    0,
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                    | android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            }
        } else {
            @SuppressWarnings("deprecation")
            int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                      | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }
}
